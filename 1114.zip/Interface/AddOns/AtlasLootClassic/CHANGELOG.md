# AtlasLootClassic

This mod is distributed under Version 2 of the GPL.  A copy of the GPL is included in this zip file with links to non-english translations.

[Changelog history](https://github.com/Hoizame/AtlasLootClassic/blob/master/AtlasLootClassic/Documentation/Release_Notes.md)

## v1.3.3 (Oct. 28, 2019)

- Fix bug with kr translation
- Droprate for Leaf and Eye should be 50% ( yes @MadSeasonShow )
