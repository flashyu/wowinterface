--
-- LibPT-Muffin.Stones
--
if not LibStub("LibPeriodicTable-3.1", true) then error("PT3 must be loaded before data") end
LibStub("LibPeriodicTable-3.1"):AddData("Muffin.Stones", "Rev: 2",
{
	["Muffin.Stones.Mana"] = "5513, 5514, 8007, 8008",
	["Muffin.Stones.Health"] = "5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006, 19007, 19008, 19009, 19010, 19011, 19012, 19013",
})
